#include "hx711.h"
#include "delay.h"
#include <stdint.h>
#include <stdlib.h>   


#ifndef HX711_GLITCH_TH_MIN
#define HX711_GLITCH_TH_MIN  20000    
#endif

#ifndef HX711_GLITCH_TH_MAX
#define HX711_GLITCH_TH_MAX  2000000  
#endif

#ifndef HX711_TIMEOUT
#define HX711_TIMEOUT 1000000
#endif

volatile uint32_t hx711_1_timeout_cnt = 0;
volatile uint32_t hx711_2_timeout_cnt = 0;
volatile uint32_t hx711_1_glitch_cnt  = 0;
volatile uint32_t hx711_2_glitch_cnt  = 0;

volatile int32_t  hx711_1_last_ok = 0;
volatile int32_t  hx711_2_last_ok = 0;
volatile int32_t  hx711_1_last_v  = 0;
volatile int32_t  hx711_2_last_v  = 0;

static inline int32_t hx711_sign_extend_24(uint32_t raw24)
{
    raw24 &= 0xFFFFFFu;
    if (raw24 & 0x800000u) raw24 |= 0xFF000000u;
    return (int32_t)raw24;
}


static inline int32_t clamp_i32(int32_t x, int32_t lo, int32_t hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static int32_t hx711_read_ch1_raw(void)
{
    uint32_t raw = 0;
    uint32_t timeout = HX711_TIMEOUT;

    HX711_SCK_L;
    delay_us(1);

    while (HX711_DT) 
		{
			if (--timeout == 0) 
			{
				hx711_1_timeout_cnt++;
				return HX711_INVALID;
			}
    }

    for (uint8_t i = 0; i < 24; i++) 
		{
			HX711_SCK_H;
			delay_us(1);
			raw = (raw << 1) | (HX711_DT ? 1u : 0u);
			HX711_SCK_L;
			delay_us(1);
    }

    HX711_SCK_H; delay_us(1);
    HX711_SCK_L; delay_us(1);

    return hx711_sign_extend_24(raw);
}

static int32_t hx711_read_ch2_raw(void)
{
    uint32_t raw = 0;
    uint32_t timeout = HX711_TIMEOUT;

    HX711_SCK2_L;
    delay_us(1);

    while (HX711_DT2) 
		{
			if (--timeout == 0) 
			{
				hx711_2_timeout_cnt++;
				return HX711_INVALID;
			}
    }

    for (uint8_t i = 0; i < 24; i++) 
		{
			HX711_SCK2_H;
			delay_us(1);
			raw = (raw << 1) | (HX711_DT2 ? 1u : 0u);
			HX711_SCK2_L;
			delay_us(1);
    }

    HX711_SCK2_H; delay_us(1);
    HX711_SCK2_L; delay_us(1);

    return hx711_sign_extend_24(raw);
}

int32_t HX711_GetData(void)
{
    static uint8_t has_last = 0;
    static int32_t ema_abs_diff = HX711_GLITCH_TH_MIN;  

    int32_t v = hx711_read_ch1_raw();
    hx711_1_last_v = v;

    if (v == HX711_INVALID) 
		{
			return has_last ? hx711_1_last_ok : 0;
    }

    if (!has_last) 
		{
			has_last = 1;
			hx711_1_last_ok = v;
			return v;
    }

    int32_t diff = abs(v - hx711_1_last_ok);

    ema_abs_diff = (int32_t)(0.9f * (float)ema_abs_diff + 0.1f * (float)diff);
    ema_abs_diff = clamp_i32(ema_abs_diff, HX711_GLITCH_TH_MIN, HX711_GLITCH_TH_MAX);

    int32_t th = ema_abs_diff * 6;
    th = clamp_i32(th, HX711_GLITCH_TH_MIN, HX711_GLITCH_TH_MAX);

    if (diff > th) 
		{
			hx711_1_glitch_cnt++;
			return hx711_1_last_ok;
    }

    hx711_1_last_ok = v;
    return v;
}


int32_t HX711_GetData2(void)
{
    static uint8_t has_last = 0;
    static int32_t ema_abs_diff = HX711_GLITCH_TH_MIN;

    int32_t v = hx711_read_ch2_raw();
    hx711_2_last_v = v;

    if (v == HX711_INVALID) 
		{
			return has_last ? hx711_2_last_ok : 0;
    }

    if (!has_last) 
		{
			has_last = 1;
			hx711_2_last_ok = v;
			return v;
    }

    int32_t diff = abs(v - hx711_2_last_ok);

    ema_abs_diff = (int32_t)(0.9f * (float)ema_abs_diff + 0.1f * (float)diff);
    ema_abs_diff = clamp_i32(ema_abs_diff, HX711_GLITCH_TH_MIN, HX711_GLITCH_TH_MAX);

    int32_t th = ema_abs_diff * 6;
    th = clamp_i32(th, HX711_GLITCH_TH_MIN, HX711_GLITCH_TH_MAX);

    if (diff > th) 
		{
			hx711_2_glitch_cnt++;
			return hx711_2_last_ok;
    }

    hx711_2_last_ok = v;
    return v;
}
