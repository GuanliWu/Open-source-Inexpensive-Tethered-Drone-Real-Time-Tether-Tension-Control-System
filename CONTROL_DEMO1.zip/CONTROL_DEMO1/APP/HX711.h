#ifndef __HX711_H
#define	__HX711_H

#include "math.h"
#include "gpio.h"
#include <stdint.h>
#define HX711_SCK_H				HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,HX711_SCK_Pin,GPIO_PIN_SET);
#define HX711_SCK_L				HAL_GPIO_WritePin(HX711_SCK_GPIO_Port,HX711_SCK_Pin,GPIO_PIN_RESET);
#define HX711_DT					HAL_GPIO_ReadPin(HX711_DATA_GPIO_Port,HX711_DATA_Pin)

#define HX711_SCK2_H				HAL_GPIO_WritePin(HX711_SCK2_GPIO_Port,HX711_SCK2_Pin,GPIO_PIN_SET);
#define HX711_SCK2_L				HAL_GPIO_WritePin(HX711_SCK2_GPIO_Port,HX711_SCK2_Pin,GPIO_PIN_RESET);
#define HX711_DT2					HAL_GPIO_ReadPin(HX711_DATA2_GPIO_Port,HX711_DATA2_Pin)

#define HX711_INVALID ((int32_t)0x80000000)
int32_t HX711_GetData(void);
int32_t HX711_GetData2(void);
int32_t HX711_GetDataEx(uint8_t *updated);
int32_t HX711_GetData2Ex(uint8_t *updated);
#endif 