#include "kalman.h"

void Kalman_Init(Kalman_t *kf, float Q, float initial_x)
{
    kf->Q = Q;
    kf->x = initial_x;
    kf->P = 1.0f;    
}
void Kalman_Predict(Kalman_t *kf)
{
    kf->P = kf->P + kf->Q;
}
float Kalman_Update(Kalman_t *kf, float z, float R)
{
    float K = kf->P / (kf->P + R);
    kf->K_last = K;

    kf->x = kf->x + K * (z - kf->x);
    kf->P = (1.0f - K) * kf->P;
    return kf->x;
}