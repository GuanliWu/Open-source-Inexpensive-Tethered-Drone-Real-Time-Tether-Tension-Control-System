#ifndef __delay_H
#define	__delay_H
#include "main.h"
#include "gpio.h"

extern uint32_t sysclk;
void dwt_int()
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	DWT->CYCCNT = 0;          
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}
void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;  
    uint32_t ticks = us * (sysclk / 1000000U);
    while((DWT->CYCCNT - start) < ticks);
}
void delay_ms(uint32_t ms)
{
	while(ms--) 
	{
		delay_us(1000);
	}
}
extern void dwt_int();
extern void delay_us(uint32_t us);
extern void delay_ms(uint32_t ms);
#endif 