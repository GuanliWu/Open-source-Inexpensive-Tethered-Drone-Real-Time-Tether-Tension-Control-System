#ifndef __FUZZYPID_H__
#define __FUZZYPID_H__

#include "main.h"
#include <stdint.h>

typedef float fp32;

enum FUZZY_PID_MODE
{
    FUZZY_PID_POSITION = 0,
    FUZZY_PID_DELTA
};

typedef enum
{
    FZ_NB = -3,
    FZ_NM = -2,
    FZ_NS = -1,
    FZ_ZO =  0,
    FZ_PS =  1,
    FZ_PM =  2,
    FZ_PB =  3
} FuzzyLevel_e;
typedef struct
{
    uint8_t mode;

    fp32 Kp;
    fp32 Ki;
    fp32 Kd;

    fp32 Kp0;
    fp32 Ki0;
    fp32 Kd0;

    fp32 max_out;
    fp32 max_iout;

    fp32 set;
    fp32 fdb;

    fp32 out;
    fp32 Pout;
    fp32 Iout;
    fp32 Dout;

    fp32 Dbuf[3];
    fp32 error[3];

    fp32 E_MAX;      
    fp32 DE_MAX;     

    fp32 DKP_MAX;    
    fp32 DKI_MAX;   
    fp32 DKD_MAX;    

    fp32 Kp_min;
    fp32 Kp_max;

    fp32 Ki_min;
    fp32 Ki_max;

    fp32 Kd_min;
    fp32 Kd_max;

    uint8_t fuzzy_enable;

} FuzzyPID_t;

extern void FuzzyPID_Init(
    FuzzyPID_t *pid,
    uint8_t mode,
    const fp32 PID[3],
    fp32 max_out,
    fp32 max_iout
);
extern void FuzzyPID_SetFuzzyRange(
    FuzzyPID_t *pid,
    fp32 E_max,
    fp32 DE_max,
    fp32 DKp_max,
    fp32 DKi_max,
    fp32 DKd_max
);		
extern void FuzzyPID_SetParaLimit(
    FuzzyPID_t *pid,
    fp32 kp_min, fp32 kp_max,
    fp32 ki_min, fp32 ki_max,
    fp32 kd_min, fp32 kd_max
);
extern void FuzzyPID_Enable(
    FuzzyPID_t *pid,
    uint8_t enable
);
extern fp32 FuzzyPID_Calc(
    FuzzyPID_t *pid,
    fp32 ref,
    fp32 set
);
extern void FuzzyPID_Clear(
    FuzzyPID_t *pid
);

#endif