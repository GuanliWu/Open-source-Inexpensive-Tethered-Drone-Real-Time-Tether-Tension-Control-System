#ifndef _KALMAN_H_
#define _KALMAN_H_
typedef struct {
    float Q;
    float x;
    float P;
    float K_last;
} Kalman_t;

extern void Kalman_Init(Kalman_t *kf, float Q, float initial_x);
extern inline void Kalman_Predict(Kalman_t *kf);
extern inline float Kalman_Update(Kalman_t *kf, float z, float R);

#endif