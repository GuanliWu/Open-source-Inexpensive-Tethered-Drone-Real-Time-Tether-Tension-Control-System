#include "mcp2515.h"
#include "gpio.h"
#include "spi.h"
#include <string.h>
#include <stdbool.h>

#define CS_LOW()   HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET)
#define CS_HIGH()  HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET)

/* ===================== ??/???? ===================== */
 uint32_t rx_ok_cnt = 0;
volatile uint32_t err_cnt   = 0;

volatile uint8_t  g_canintf = 0;
volatile uint8_t  g_eflg    = 0;
volatile uint8_t  g_rec     = 0;
volatile uint8_t  g_tec     = 0;

volatile mcp2515_frame_t g_last_frame;

volatile uint32_t tx_ok = 0, tx_fail = 0;

/* ===================== VESC ===================== */
#define VESC_ID  43
#define VESC_CMD_SET_RPM      0x03
#define VESC_CMD_SET_CURRENT  0x01
#define VESC_CMD_SET_DUTY     0x00

/* ===================== MCP2515 SPI CMD ===================== */
#define CMD_RESET       0xC0
#define CMD_READ        0x03
#define CMD_WRITE       0x02
#define CMD_BIT_MODIFY  0x05

/* ===================== MCP2515 REG ===================== */
#define REG_TXB0CTRL  0x30
#define TXREQ         0x08

#define REG_EFLG      0x2D
#define REG_REC       0x1D
#define REG_TEC       0x1C

#define REG_CANSTAT   0x0E
#define REG_CANCTRL   0x0F

#define REG_CNF3      0x28
#define REG_CNF2      0x29
#define REG_CNF1      0x2A

#define REG_CANINTE   0x2B
#define REG_CANINTF   0x2C

#define REG_RXB0CTRL  0x60
#define REG_RXB0SIDH  0x61
#define REG_RXB1CTRL  0x70
#define REG_RXB1SIDH  0x71

/* ===================== MODE ===================== */
#define MODE_NORMAL   0x00
#define MODE_CONFIG   0x80

/* ===================== CANINTF bits ===================== */
#define RX0IF   0x01
#define RX1IF   0x02
#define TX0IF   0x04
#define TX1IF   0x08
#define TX2IF   0x10
#define ERRIF   0x20
#define WAKIF   0x40
#define MERRF   0x80

/* ===================== CANINTE bits ===================== */
#define RX0IE   0x01
#define RX1IE   0x02
#define ERRIE   0x20
#define WAKIE   0x40
#define MERRE   0x80

/* ===================== EFLG bits ===================== */
#define EWARN   0x01
#define RXWAR   0x02
#define TXWAR   0x04
#define RXEP    0x08
#define TXEP    0x10
#define TXBO    0x20
#define RX0OVR  0x40
#define RX1OVR  0x80

#define BUKT          0x04
#define RXM_MASK      0x60   


static inline void spi_tx(const uint8_t *p, uint16_t n) {
  (void)HAL_SPI_Transmit(&hspi2, (uint8_t*)p, n, HAL_MAX_DELAY);
}
static inline void spi_rx(uint8_t *p, uint16_t n) {
  (void)HAL_SPI_Receive(&hspi2, p, n, HAL_MAX_DELAY);
}
static inline void spi_txrx(const uint8_t *tx, uint8_t *rx, uint16_t n) {
  (void)HAL_SPI_TransmitReceive(&hspi2, (uint8_t*)tx, rx, n, HAL_MAX_DELAY);
}


void mcp2515_reset(void)
{
  uint8_t cmd = CMD_RESET;
  CS_LOW();
  spi_tx(&cmd, 1);
  CS_HIGH();
  HAL_Delay(2);
}

uint8_t mcp2515_read_reg(uint8_t addr)
{
  uint8_t tx[3] = { CMD_READ, addr, 0x00 };
  uint8_t rx[3] = { 0 };
  CS_LOW();
  spi_txrx(tx, rx, 3);
  CS_HIGH();
  return rx[2];
}

static void write_reg(uint8_t addr, uint8_t val)
{
  uint8_t tx[3] = { CMD_WRITE, addr, val };
  CS_LOW();
  spi_tx(tx, 3);
  CS_HIGH();
}

static void read_regs(uint8_t addr, uint8_t *buf, uint8_t len)
{
  uint8_t hdr[2] = { CMD_READ, addr };
  CS_LOW();
  spi_tx(hdr, 2);
  spi_rx(buf, len);
  CS_HIGH();
}

static void bit_modify(uint8_t addr, uint8_t mask, uint8_t data)
{
  uint8_t tx[4] = { CMD_BIT_MODIFY, addr, mask, data };
  CS_LOW();
  spi_tx(tx, 4);
  CS_HIGH();
}

static bool set_mode(uint8_t mode)
{
  bit_modify(REG_CANCTRL, 0xE0, mode);

  for (int i = 0; i < 50; i++) {
    if ((mcp2515_read_reg(REG_CANSTAT) & 0xE0) == mode) return true;
    HAL_Delay(1);
  }
  return false;
}

static void mcp2515_rts_tx0(void)
{
  uint8_t cmd = 0x81; // RTS TX0
  CS_LOW();
  (void)HAL_SPI_Transmit(&hspi2, &cmd, 1, HAL_MAX_DELAY);
  CS_HIGH();
}

static void mcp2515_load_tx0_ext(uint32_t id, const uint8_t *data, uint8_t dlc)
{
  if (dlc > 8) dlc = 8;

  uint8_t sidh = (id >> 21) & 0xFF;
  uint8_t sidl = (uint8_t)(((id >> 16) & 0x03) | (((id >> 13) & 0x07) << 5) | 0x08); // IDE=1
  uint8_t eid8 = (id >> 8) & 0xFF;
  uint8_t eid0 = id & 0xFF;

  write_reg(0x31, sidh);
  write_reg(0x32, sidl);
  write_reg(0x33, eid8);
  write_reg(0x34, eid0);
  write_reg(0x35, dlc & 0x0F);

  for (uint8_t i = 0; i < dlc; i++) write_reg(0x36 + i, data[i]);
}


bool mcp2515_send_ext_nb(uint32_t id, const uint8_t *data, uint8_t dlc)
{
  if (mcp2515_read_reg(REG_TXB0CTRL) & TXREQ) {
    return false;
  }

  mcp2515_load_tx0_ext(id, data, dlc);
  mcp2515_rts_tx0();
  return true;
}


bool mcp2515_init(void)
{
  mcp2515_reset();
  if (!set_mode(MODE_CONFIG)) return false;

 
  write_reg(REG_CNF1, 0x00);
  write_reg(REG_CNF2, 0xB5);
  write_reg(REG_CNF3, 0x05);

  
  bit_modify(REG_RXB0CTRL, RXM_MASK, 0x00);
  bit_modify(REG_RXB1CTRL, RXM_MASK, 0x00);

  bit_modify(REG_RXB0CTRL, BUKT, BUKT);

  write_reg(REG_CANINTE, (RX0IE | RX1IE | ERRIE | MERRE));

  write_reg(REG_CANINTF, 0x00);

  
  bit_modify(REG_EFLG, 0xFF, 0x00);

  return set_mode(MODE_NORMAL);
}

static void parse_frame_from_rxb(uint8_t sidh_reg, mcp2515_frame_t *f)
{
  uint8_t b[13];
  read_regs(sidh_reg, b, 13);

  uint8_t sidh = b[0];
  uint8_t sidl = b[1];
  uint8_t eid8 = b[2];
  uint8_t eid0 = b[3];
  uint8_t dlc  = b[4];

  f->dlc = dlc & 0x0F;
  if (f->dlc > 8) f->dlc = 8;

  f->ext = (sidl & 0x08) ? 1 : 0;
  f->rtr = (dlc  & 0x40) ? 1 : 0;

  if (f->ext) {
    f->sid =
      ((uint32_t)sidh << 21) |
      ((uint32_t)(sidl & 0xE0) << 13) |
      ((uint32_t)(sidl & 0x03) << 16) |
      ((uint32_t)eid8 << 8) |
      (uint32_t)eid0;
  } else {
    f->sid = ((uint32_t)sidh << 3) | (sidl >> 5);
  }

  for (uint8_t i = 0; i < f->dlc; i++) {
    f->data[i] = b[5 + i];
  }
}

static void mcp2515_handle_error(uint8_t intf)
{
  (void)intf;
  err_cnt++;

  g_canintf = intf;
  g_eflg = mcp2515_read_reg(REG_EFLG);
  g_rec  = mcp2515_read_reg(REG_REC);
  g_tec  = mcp2515_read_reg(REG_TEC);

  
  bit_modify(REG_CANINTF, (ERRIF | MERRF), 0x00);

  if (g_eflg & (RX0OVR | RX1OVR)) {
    bit_modify(REG_EFLG, (RX0OVR | RX1OVR), 0x00);
  }

}

bool mcp2515_irq_handler(mcp2515_frame_t *f)
{
  uint8_t intf = mcp2515_read_reg(REG_CANINTF);
  g_canintf = intf;

  
  if (intf & (ERRIF | MERRF)) {
    mcp2515_handle_error(intf);
    
  }

  if (intf & RX0IF) {
    parse_frame_from_rxb(REG_RXB0SIDH, f);
    memcpy((void*)&g_last_frame, f, sizeof(*f));
    rx_ok_cnt++;
    bit_modify(REG_CANINTF, RX0IF, 0x00);
    return true;
  }

  if (intf & RX1IF) {
    parse_frame_from_rxb(REG_RXB1SIDH, f);
    memcpy((void*)&g_last_frame, f, sizeof(*f));
    rx_ok_cnt++;
    bit_modify(REG_CANINTF, RX1IF, 0x00);
    return true;
  }

  return false;
}


void mcp2515_service(void)
{
  mcp2515_frame_t f;
  uint16_t guard = 0;

  while (guard++ < 64)
  {
    uint8_t intf = mcp2515_read_reg(REG_CANINTF);
    g_canintf = intf;

    if (intf & (ERRIF | MERRF)) {
      mcp2515_handle_error(intf);
      continue;
    }

    if (intf & RX0IF) {
      parse_frame_from_rxb(REG_RXB0SIDH, &f);
      memcpy((void*)&g_last_frame, &f, sizeof(f));
      rx_ok_cnt++;
      bit_modify(REG_CANINTF, RX0IF, 0x00);
      continue;
    }

    if (intf & RX1IF) {
      parse_frame_from_rxb(REG_RXB1SIDH, &f);
      memcpy((void*)&g_last_frame, &f, sizeof(f));
      rx_ok_cnt++;
      bit_modify(REG_CANINTF, RX1IF, 0x00);
      continue;
    }

    break;
  }
}


bool vesc_set_rpm(int32_t rpm)
{
  uint8_t data[8] = {0};
  data[0] = (uint8_t)((rpm >> 24) & 0xFF);
  data[1] = (uint8_t)((rpm >> 16) & 0xFF);
  data[2] = (uint8_t)((rpm >>  8) & 0xFF);
  data[3] = (uint8_t)( rpm        & 0xFF);

  uint32_t can_id = ((uint32_t)VESC_CMD_SET_RPM << 8) | (uint32_t)VESC_ID;
  bool ok = mcp2515_send_ext_nb(can_id, data, 8);
  if (ok) tx_ok++; else tx_fail++;
  return ok;
}

bool vesc_set_current(fp32 current_A)
{
  int32_t current_mA = (int32_t)(current_A * 1000.0f);

  uint8_t data[8] = {0};
  data[0] = (uint8_t)((current_mA >> 24) & 0xFF);
  data[1] = (uint8_t)((current_mA >> 16) & 0xFF);
  data[2] = (uint8_t)((current_mA >>  8) & 0xFF);
  data[3] = (uint8_t)( current_mA        & 0xFF);

  uint32_t can_id = ((uint32_t)VESC_CMD_SET_CURRENT << 8) | (uint32_t)VESC_ID;

  bool ok = mcp2515_send_ext_nb(can_id, data, 8);
  if (ok) tx_ok++; else tx_fail++;
  return ok;
}

bool vesc_set_duty(float duty)
{
  if (duty >  0.95f) duty =  0.95f;
  if (duty < -0.95f) duty = -0.95f;

  int32_t duty_i = (int32_t)(duty * 100000.0f);

  uint8_t data[8] = {0};
  data[0] = (uint8_t)((duty_i >> 24) & 0xFF);
  data[1] = (uint8_t)((duty_i >> 16) & 0xFF);
  data[2] = (uint8_t)((duty_i >>  8) & 0xFF);
  data[3] = (uint8_t)( duty_i        & 0xFF);

  uint32_t can_id = ((uint32_t)VESC_CMD_SET_DUTY << 8) | (uint32_t)VESC_ID;

  bool ok = mcp2515_send_ext_nb(can_id, data, 8);
  if (ok) tx_ok++; else tx_fail++;
  return ok;
}
