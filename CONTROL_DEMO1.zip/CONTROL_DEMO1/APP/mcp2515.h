#ifndef MCP2515_H
#define MCP2515_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

extern SPI_HandleTypeDef hspi1;

typedef struct {
  uint32_t  sid;     
  uint8_t  dlc;     
  uint8_t  data[8]; 
	 uint8_t  ext;    
  uint8_t  rtr;    
} mcp2515_frame_t;
typedef struct {
  // STATUS_1
  int32_t erpm;
  int16_t motor_current_x10;
  int16_t duty_x1000;

  // STATUS_2
  int32_t ah_x10000;
  int32_t ah_chg_x10000;

  // STATUS_3
  int32_t wh_x10000;
  int32_t wh_chg_x10000;

  // STATUS_4
  int16_t temp_fet_x10;
  int16_t temp_motor_x10;
  int16_t current_in_x10;
  int16_t pid_pos_x50;
} vesc_raw_t;


bool mcp2515_init(void);

bool mcp2515_irq_handler(mcp2515_frame_t *f);
bool vesc_set_rpm(int32_t rpm);
bool vesc_set_current(float current_A);
bool vesc_set_duty(float duty);
void    mcp2515_reset(void);
uint8_t mcp2515_read_reg(uint8_t addr);
void write_reg(uint8_t addr, uint8_t val);
void bit_modify(uint8_t addr, uint8_t mask, uint8_t data);
void mcp2515_load_tx0(uint16_t sid, const uint8_t *data, uint8_t dlc);
void mcp2515_rts_tx0(void);
void mcp2515_service(void);
#endif
