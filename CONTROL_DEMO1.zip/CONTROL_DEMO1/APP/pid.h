#ifndef PID_H
#define PID_H

#define ecd_range 8191
#define half_ecd_range 4096

#define PI 3.1415926535f

#include "main.h"
enum PID_MODE
{
    PID_POSITION = 0,
    PID_DELTA
};

typedef float fp32;

typedef struct
{
    uint8_t mode;
    
    fp32 Kp;
    fp32 Ki;
    fp32 Kd;

    fp32 max_out;  
    fp32 max_iout; 

    fp32 set;
    fp32 fdb;

    fp32 out;
    fp32 Pout;
    fp32 Iout;
    fp32 Dout;
    fp32 Dbuf[3];  
    fp32 error[3]; 

} PidTypeDef;
extern void PID_Init(PidTypeDef *pid, uint8_t mode, const fp32 PID[3], fp32 max_out, fp32 max_iout);
extern fp32 PID_Calc(PidTypeDef *pid, fp32 ref, fp32 set);
extern fp32 PID_Calc_Ecd(PidTypeDef *pid, fp32 ref, fp32 set);
extern fp32 PID_Calc_Angle(PidTypeDef *pid, fp32 ref, fp32 set);
extern void PID_clear(PidTypeDef *pid);
extern fp32 PID_Cal(PidTypeDef *pid, fp32 ref, fp32 set);
void Ecd_zero(float *set,float *ref);
static fp32 ecd_zero(uint16_t ecd, uint16_t offset_ecd);
fp32 angle_zero(fp32 angle, fp32 offset_angle);

#endif
