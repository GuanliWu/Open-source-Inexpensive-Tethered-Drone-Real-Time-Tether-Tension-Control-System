/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId Time_C_TaskHandle;
osThreadId Motor_C_TaskHandle;
osThreadId User_C_TaskHandle;
osThreadId Hx711_C_TaskHandle;
osThreadId Vofa_C_TaskHandle;
osThreadId Control_TaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void TIME_C_TASK(void const * argument);
void MOTOR_C_TASK(void const * argument);
void USER_C_TASK(void const * argument);
void HX711_C_TASK(void const * argument);
void VOFA_C_TASK(void const * argument);
void CONTROL_TASK(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* GetTimerTaskMemory prototype (linked to static allocation support) */
void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/* USER CODE BEGIN GET_TIMER_TASK_MEMORY */
static StaticTask_t xTimerTaskTCBBuffer;
static StackType_t xTimerStack[configTIMER_TASK_STACK_DEPTH];

void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize )
{
  *ppxTimerTaskTCBBuffer = &xTimerTaskTCBBuffer;
  *ppxTimerTaskStackBuffer = &xTimerStack[0];
  *pulTimerTaskStackSize = configTIMER_TASK_STACK_DEPTH;
  /* place for user code */
}
/* USER CODE END GET_TIMER_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of Time_C_Task */
  osThreadDef(Time_C_Task, TIME_C_TASK, osPriorityNormal, 0, 128);
  Time_C_TaskHandle = osThreadCreate(osThread(Time_C_Task), NULL);

  /* definition and creation of Motor_C_Task */
  osThreadDef(Motor_C_Task, MOTOR_C_TASK, osPriorityIdle, 0, 256);
  Motor_C_TaskHandle = osThreadCreate(osThread(Motor_C_Task), NULL);

  /* definition and creation of User_C_Task */
  osThreadDef(User_C_Task, USER_C_TASK, osPriorityIdle, 0, 128);
  User_C_TaskHandle = osThreadCreate(osThread(User_C_Task), NULL);

  /* definition and creation of Hx711_C_Task */
  osThreadDef(Hx711_C_Task, HX711_C_TASK, osPriorityIdle, 0, 128);
  Hx711_C_TaskHandle = osThreadCreate(osThread(Hx711_C_Task), NULL);

  /* definition and creation of Vofa_C_Task */
  osThreadDef(Vofa_C_Task, VOFA_C_TASK, osPriorityIdle, 0, 128);
  Vofa_C_TaskHandle = osThreadCreate(osThread(Vofa_C_Task), NULL);

  /* definition and creation of Control_Task */
  osThreadDef(Control_Task, CONTROL_TASK, osPriorityIdle, 0, 128);
  Control_TaskHandle = osThreadCreate(osThread(Control_Task), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_TIME_C_TASK */
/**
  * @brief  Function implementing the Time_C_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_TIME_C_TASK */
__weak void TIME_C_TASK(void const * argument)
{
  /* USER CODE BEGIN TIME_C_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END TIME_C_TASK */
}

/* USER CODE BEGIN Header_MOTOR_C_TASK */
/**
* @brief Function implementing the Motor_C_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_MOTOR_C_TASK */
__weak void MOTOR_C_TASK(void const * argument)
{
  /* USER CODE BEGIN MOTOR_C_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END MOTOR_C_TASK */
}

/* USER CODE BEGIN Header_USER_C_TASK */
/**
* @brief Function implementing the User_C_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_USER_C_TASK */
__weak void USER_C_TASK(void const * argument)
{
  /* USER CODE BEGIN USER_C_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END USER_C_TASK */
}

/* USER CODE BEGIN Header_HX711_C_TASK */
/**
* @brief Function implementing the Hx711_C_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_HX711_C_TASK */
__weak void HX711_C_TASK(void const * argument)
{
  /* USER CODE BEGIN HX711_C_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END HX711_C_TASK */
}

/* USER CODE BEGIN Header_VOFA_C_TASK */
/**
* @brief Function implementing the Vofa_C_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_VOFA_C_TASK */
__weak void VOFA_C_TASK(void const * argument)
{
  /* USER CODE BEGIN VOFA_C_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END VOFA_C_TASK */
}

/* USER CODE BEGIN Header_CONTROL_TASK */
/**
* @brief Function implementing the Control_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_CONTROL_TASK */
__weak void CONTROL_TASK(void const * argument)
{
  /* USER CODE BEGIN CONTROL_TASK */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END CONTROL_TASK */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
