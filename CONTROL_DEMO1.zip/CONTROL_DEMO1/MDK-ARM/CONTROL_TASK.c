#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "pid.h"
#include "fuzzy_pid.h"
#include "mcp2515.h"
#include <math.h>

uint8_t mode;

typedef enum
{
    Motor_stop  = 0,
    Motor_start = 1,
} MODE_e;

#define H_KP 2.5f
#define H_KI 0.08f
#define H_KD 0.08f
#define H_I_LIMIT 4.0f
#define H_U_MAX 12.0f
#define H_U_MIN -12.0f
static const fp32 PID_X[] = {H_KP, H_KI, H_KD};
PidTypeDef pid_h;

#define M_KP 2.5f
#define M_KI 0.08f
#define M_KD 0.08f
#define M_MAX 12.0f

static const fp32 PID_M_BASE[] = {M_KP, M_KI, M_KD};
static FuzzyPID_t fpid_m;

fp32 PID_Current_M;
fp32 tenstion = 0;
fp32 current  = 0;

extern uint8_t start;
extern fp32 weight_raw_total;
extern fp32 weight_rea_total;

extern struct
{
    fp32 erpm;
} g_vesc_raw;

#define E_DEAD           0.2f
#define COMP_STEP        0.0f
#define I_DEADBAND       2.0f

#define SLEW_PULL        0.015f
#define SLEW_RELAX       0.015f

#define E_IN_HOLD        0.20f
#define E_OUT_HOLD       0.40f
#define HOLD_ENTER_CNT   12u
#define HOLD_EXIT_CNT_TH 5u

#define CAP_BLEND_STEPS  30u

fp32 mea_last_ok = 0.0f;
uint8_t mea_inited = 0;
fp32 mea = 0;
fp32 JUMP_TH = 0.8f;

fp32 pull_send = 0.0f;

typedef enum
{
    TCTRL_CAPTURE = 0,
    TCTRL_HOLD    = 1,
} tctrl_state_e;

typedef enum
{
    LINE_DIR_RELEASE = 0,
    LINE_DIR_RETRACT = 1
} line_dir_e;

static fp32 pull_last = 0.0f;
static tctrl_state_e tstate = TCTRL_CAPTURE;
static line_dir_e line_dir = LINE_DIR_RETRACT;

static uint16_t hold_cnt = 0;
static uint16_t hold_exit_cnt = 0;
static fp32 pull_base = 0.0f;

static uint8_t cap_blend_active = 0;
static uint16_t cap_blend_cnt = 0;
static fp32 cap_blend_start = 0.0f;

#define ERPM_DIR_TH 50.0f

#define USE_FEEDFORWARD           1
#define PULL_FF_PER_N_RETRACT     0.15f
#define PULL_FF_PER_N_RELEASE     0.15f
#define PULL_FF_LIMIT             10.5f

#define USE_TENSION_DAMPING       1
#define CTRL_DT                   0.002f
#define DAMP_ALPHA                0.20f

#define K_DAMP_T_RETRACT          0.001f
#define PULL_DAMP_LIMIT_RETRACT   1.0f

#define K_DAMP_T_RELEASE          0.0015f
#define PULL_DAMP_LIMIT_RELEASE   1.5f

static fp32 mea_prev = 0.0f;
static uint8_t mea_prev_inited = 0;
static fp32 dmea_filt = 0.0f;

static inline fp32 clamp_fp32(fp32 x, fp32 lo, fp32 hi)
{
    if (x > hi) return hi;
    if (x < lo) return lo;
    return x;
}

static inline void update_line_dir_by_erpm(fp32 erpm)
{
    if (erpm > ERPM_DIR_TH)
    {
        line_dir = LINE_DIR_RELEASE;
    }
    else if (erpm < -ERPM_DIR_TH)
    {
        line_dir = LINE_DIR_RETRACT;
    }
    else
    {
        
    }
}

static inline fp32 get_ff_per_n_by_dir(line_dir_e dir)
{
    return (dir == LINE_DIR_RETRACT) ? PULL_FF_PER_N_RETRACT : PULL_FF_PER_N_RELEASE;
}

static inline fp32 get_k_damp_by_dir(line_dir_e dir)
{
    return (dir == LINE_DIR_RETRACT) ? K_DAMP_T_RETRACT : K_DAMP_T_RELEASE;
}

static inline fp32 get_damp_limit_by_dir(line_dir_e dir)
{
    return (dir == LINE_DIR_RETRACT) ? PULL_DAMP_LIMIT_RETRACT : PULL_DAMP_LIMIT_RELEASE;
}

static fp32 get_dynamic_m_i_limit(fp32 set)
{
    fp32 out;

    if (set <= 0.5f)
        return 2.0f;

    if (set >= 4.0f)
        return 10.0f;

    out = 2.0f + (set - 0.5f) * (10.0f - 2.0f) / (4.0f - 0.5f);
    return out;
}

static inline void pid_reset_soft(PidTypeDef *pid)
{
    pid->Iout = 0.0f;
    pid->out  = 0.0f;
    pid->error[0] = 0.0f;
    pid->error[1] = 0.0f;
    pid->error[2] = 0.0f;
}

static inline void fuzzy_soft_reset(FuzzyPID_t *pid)
{
    if (pid == NULL) return;

    pid->Iout = 0.0f;
    pid->Pout = 0.0f;
    pid->Dout = 0.0f;
    pid->out  = 0.0f;

    pid->error[0] = 0.0f;
    pid->error[1] = 0.0f;
    pid->error[2] = 0.0f;

    pid->Dbuf[0] = 0.0f;
    pid->Dbuf[1] = 0.0f;
    pid->Dbuf[2] = 0.0f;

    pid->Kp = pid->Kp0;
    pid->Ki = pid->Ki0;
    pid->Kd = pid->Kd0;
}

static fp32 clamp_and_slew_pull(fp32 pull_cmd, fp32 max_pull, fp32 *plast)
{
    fp32 local_step;
    fp32 local_d;

    pull_cmd = clamp_fp32(pull_cmd, -max_pull, max_pull);

    local_step = (pull_cmd >= *plast) ? SLEW_RELAX : SLEW_PULL;
    local_d = pull_cmd - *plast;

    if (local_d >  local_step) local_d =  local_step;
    if (local_d < -local_step) local_d = -local_step;

    pull_cmd = *plast + local_d;
    *plast = pull_cmd;
    return pull_cmd;
}

static void damping_reset(fp32 mea_now)
{
    mea_prev = mea_now;
    mea_prev_inited = 1;
    dmea_filt = 0.0f;
}

static fp32 calc_tension_damping(fp32 mea_now, line_dir_e dir)
{
    fp32 dmea = 0.0f;
    fp32 pull_damp = 0.0f;
    fp32 k_damp = get_k_damp_by_dir(dir);
    fp32 damp_limit = get_damp_limit_by_dir(dir);

    if (!mea_prev_inited)
    {
        damping_reset(mea_now);
    }

    dmea = (mea_now - mea_prev) / CTRL_DT;
    mea_prev = mea_now;

    dmea_filt = DAMP_ALPHA * dmea + (1.0f - DAMP_ALPHA) * dmea_filt;

    pull_damp = -k_damp * dmea_filt;
    pull_damp = clamp_fp32(pull_damp, -damp_limit, damp_limit);

    return pull_damp;
}

void pid_all_init(void)
{
    PID_Init(&pid_h, PID_POSITION, PID_X, H_U_MAX, H_I_LIMIT);

    FuzzyPID_Init(&fpid_m, FUZZY_PID_POSITION, PID_M_BASE, M_MAX, 3.0f);

    FuzzyPID_SetFuzzyRange(&fpid_m,
                           1.0f,
                           0.8f,
                           6.0f,
                           0.1f,
                           0.2f);

    FuzzyPID_SetParaLimit(&fpid_m,
                          0.0f, 10.0f,
                          0.0f, 0.4f,
                          0.0f, 0.8f);

    FuzzyPID_Enable(&fpid_m, 1);
}

void motor_mode_switch(void)
{
    if (start == 0)
        mode = Motor_stop;
    else if (start == 1)
        mode = Motor_start;
}

void Motor_target_calc(uint8_t Mode)
{
    if (Mode == Motor_stop)
    {
        current = 0.0f;
    }
    else if (Mode == Motor_start)
    {
        tenstion = 1.0f;
    }
}

static fp32 tension_ctrl_calc_pull(fp32 mea_now, fp32 set)
{
    fp32 e = set - mea_now;
    fp32 pull_cmd = 0.0f;
    fp32 base_i_limit;

    update_line_dir_by_erpm(g_vesc_raw.erpm);

    base_i_limit = get_dynamic_m_i_limit(set);

    if (line_dir == LINE_DIR_RETRACT)
        fpid_m.max_iout = base_i_limit;
    else
        fpid_m.max_iout = 0.8f * base_i_limit;

    if (tstate == TCTRL_CAPTURE)
    {
        fp32 pull_pid;
        fp32 pull_ff;
        fp32 pull_damp;
        fp32 pull_cap_raw;
        fp32 alpha;

       
        pull_pid = FuzzyPID_Calc(&fpid_m, mea_now, set);

#if USE_FEEDFORWARD
        
        if (fabsf(e) > E_DEAD)
            pull_ff = get_ff_per_n_by_dir(line_dir) * e;
        else
            pull_ff = 0.0f;

        pull_ff = clamp_fp32(pull_ff, -PULL_FF_LIMIT, PULL_FF_LIMIT);
#else
        pull_ff = 0.0f;
#endif

#if USE_TENSION_DAMPING
        pull_damp = calc_tension_damping(mea_now, line_dir);
#else
        pull_damp = 0.0f;
#endif

        pull_cap_raw = pull_ff + pull_pid + pull_damp;

        if (e > E_DEAD)
        {
            if (pull_cap_raw < I_DEADBAND)
                pull_cap_raw += COMP_STEP;
        }
        else if (e < -E_DEAD)
        {
            if (pull_cap_raw > -I_DEADBAND)
                pull_cap_raw -= COMP_STEP;
        }

        if (cap_blend_active)
        {
            alpha = (fp32)cap_blend_cnt / (fp32)CAP_BLEND_STEPS;
            if (alpha > 1.0f) alpha = 1.0f;

            pull_cap_raw = (1.0f - alpha) * cap_blend_start + alpha * pull_cap_raw;

            cap_blend_cnt++;
            if (cap_blend_cnt >= CAP_BLEND_STEPS)
            {
                cap_blend_active = 0;
            }
        }

        PID_Current_M = clamp_and_slew_pull(pull_cap_raw, M_MAX, &pull_last);

        if (fabsf(e) < E_IN_HOLD)
        {
            hold_cnt++;
            if (hold_cnt >= HOLD_ENTER_CNT)
            {
                pull_base = PID_Current_M;

                pid_reset_soft(&pid_h);
                fuzzy_soft_reset(&fpid_m);

                tstate = TCTRL_HOLD;
                hold_cnt = 0;
                hold_exit_cnt = 0;
                cap_blend_active = 0;
                cap_blend_cnt = 0;
            }
        }
        else
        {
            hold_cnt = 0;
        }

        return PID_Current_M;
    }
    else
    {
        fp32 u;
        u = PID_Calc(&pid_h, mea_now, set);
        u = clamp_fp32(u, H_U_MIN, H_U_MAX);

        pull_cmd = pull_base + u;

        PID_Current_M = clamp_and_slew_pull(pull_cmd, M_MAX, &pull_last);

        if (fabsf(e) > E_OUT_HOLD)
        {
            hold_exit_cnt++;
            if (hold_exit_cnt >= HOLD_EXIT_CNT_TH)
            {
                pid_reset_soft(&pid_h);
                fuzzy_soft_reset(&fpid_m);

                pull_last = PID_Current_M;
                tstate = TCTRL_CAPTURE;
                hold_cnt = 0;
                hold_exit_cnt = 0;

                cap_blend_active = 1;
                cap_blend_cnt = 0;
                cap_blend_start = PID_Current_M;

#if USE_TENSION_DAMPING
                damping_reset(mea_now);
#endif
            }
        }
        else
        {
            hold_exit_cnt = 0;
        }

        return PID_Current_M;
    }
}

void Motor_calc_cmd(uint8_t Mode)
{
    if (Mode == Motor_stop)
    {
        vesc_set_current(0.0f);

        pid_reset_soft(&pid_h);
        fuzzy_soft_reset(&fpid_m);

        pull_last = 0.0f;
        tstate = TCTRL_CAPTURE;
        hold_cnt = 0;
        hold_exit_cnt = 0;
        pull_base = 0.0f;

        cap_blend_active = 0;
        cap_blend_cnt = 0;
        cap_blend_start = 0.0f;

        mea_inited = 0;
        mea_prev_inited = 0;
        dmea_filt = 0.0f;
        mea_last_ok = 0.0f;
        mea = 0.0f;

        line_dir = LINE_DIR_RETRACT;
        return;
    }

    mea = weight_rea_total;
    mea_last_ok = mea;

    pull_send = tension_ctrl_calc_pull(mea, tenstion);

    vesc_set_current(pull_send);
}

void CONTROL_TASK(void const * argument)
{
    mode = Motor_stop;
    pid_all_init();

    while (1)
    {
        motor_mode_switch();
        Motor_target_calc(mode);
        Motor_calc_cmd(mode);
        vTaskDelay(2);
    }
}