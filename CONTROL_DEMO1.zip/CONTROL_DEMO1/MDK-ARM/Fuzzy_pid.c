#include "fuzzy_pid.h"
#include <math.h>

#define LimitMax(input, max)   \
    {                          \
        if (input > max)       \
        {                      \
            input = max;       \
        }                      \
        else if (input < -max) \
        {                      \
            input = -max;      \
        }                      \
    }
		
static inline fp32 clamp_fp32(fp32 x, fp32 lo, fp32 hi)
{
    if (x > hi) return hi;
    if (x < lo) return lo;
    return x;
}		
static const int8_t RULE_DKP[7][7] = {
 /* de:   NB  NM  NS  ZO  PS  PM  PB */
 /* e NB */ { +3, +3, +2, +2, +1,  0,  0 },
 /* e NM */ { +3, +2, +2, +1,  0,  0, -1 },
 /* e NS */ { +2, +2, +1,  0, -1, -2, -2 },
 /* e ZO */ { +2, +1,  0,  0,  0, -1, -2 },
 /* e PS */ { -2, -2, -1,  0, +1, +2, +2 },
 /* e PM */ { -1,  0,  0, +1, +2, +2, +3 },
 /* e PB */ {  0,  0, +1, +2, +2, +3, +3 }
};
static const int8_t RULE_DKI[7][7] = {
 /* de:   NB  NM  NS  ZO  PS  PM  PB */
 /* e NB */ { -1, -2, -2, -3, -3, -3, -3 },
 /* e NM */ {  0, -1, -2, -2, -3, -3, -3 },
 /* e NS */ { +1,  0, -1, -2, -2, -3, -3 },
 /* e ZO */ { +2, +1,  0,  0,  0, -1, -2 },
 /* e PS */ { +3, +2, +1,  0,  0, -1, -2 },
 /* e PM */ { +3, +3, +2, +1,  0, -1, -1 },
 /* e PB */ { +3, +3, +3, +2, +1, -1,  0 }
};
static const int8_t RULE_DKD[7][7] = {
 /* de:   NB  NM  NS  ZO  PS  PM  PB */
 /* e NB */ { +3, +2, +2, +1,  0,  0, -1 },
 /* e NM */ { +2, +2, +1,  0, -1, -2, -2 },
 /* e NS */ { +2, +1,  0, -1, -2, -2, -3 },
 /* e ZO */ { +1,  0, -1, -2, -2,  0, +1 },
 /* e PS */ { -3, -2, -2, -2, -1,  0, +1 },
 /* e PM */ { -2, -2, -1,  0, +1, +2, +2 },
 /* e PB */ { -1,  0,  0, +1, +2, +2, +3 }
};
static void fuzzify_7(fp32 x, fp32 mu[7])
{
    const fp32 c[7] = { -1.0f, -0.6666667f, -0.3333333f, 0.0f, 0.3333333f, 0.6666667f, 1.0f };

    mu[0] = mu[1] = mu[2] = mu[3] = mu[4] = mu[5] = mu[6] = 0.0f;

    if (x <= -1.0f) { mu[0] = 1.0f; return; }
    if (x >=  1.0f) { mu[6] = 1.0f; return; }

    for (int i = 0; i < 6; i++)
    {
        if (x >= c[i] && x <= c[i + 1])
        {
            fp32 span = (c[i + 1] - c[i]);     /* = 1/3 */
            fp32 t = (x - c[i]) / span;        /* 0..1 */
            mu[i]     = 1.0f - t;
            mu[i + 1] = t;
            return;
        }
    }
}
static fp32 fuzzy_infer(const fp32 mu_e[7], const fp32 mu_de[7], const int8_t rule[7][7])
{
    fp32 num = 0.0f;
    fp32 den = 0.0f;

    for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            fp32 w = (mu_e[i] < mu_de[j]) ? mu_e[i] : mu_de[j];
            if (w <= 0.0f) continue;

            num += w * (fp32)rule[i][j];
            den += w;
        }
    }

    if (den < 1e-6f) return 0.0f;
    return num / den;
}
static void fuzzy_update_gains(FuzzyPID_t *pid, fp32 e, fp32 de)
{
    
    fp32 en  = (pid->E_MAX  > 1e-6f) ? (e  / pid->E_MAX)  : 0.0f;
    fp32 den = (pid->DE_MAX > 1e-6f) ? (de / pid->DE_MAX) : 0.0f;

    en  = clamp_fp32(en,  -1.0f, 1.0f);
    den = clamp_fp32(den, -1.0f, 1.0f);

    fp32 mu_e[7], mu_de[7];
    fuzzify_7(en,  mu_e);
    fuzzify_7(den, mu_de);

    
    fp32 lv_kp = fuzzy_infer(mu_e, mu_de, RULE_DKP);
    fp32 lv_ki = fuzzy_infer(mu_e, mu_de, RULE_DKI);
    fp32 lv_kd = fuzzy_infer(mu_e, mu_de, RULE_DKD);

    
    fp32 dKp = lv_kp * (pid->DKP_MAX / 3.0f);
    fp32 dKi = lv_ki * (pid->DKI_MAX / 3.0f);
    fp32 dKd = lv_kd * (pid->DKD_MAX / 3.0f);

   
    pid->Kp = clamp_fp32(pid->Kp0 + dKp, pid->Kp_min, pid->Kp_max);
    pid->Ki = clamp_fp32(pid->Ki0 + dKi, pid->Ki_min, pid->Ki_max);
    pid->Kd = clamp_fp32(pid->Kd0 + dKd, pid->Kd_min, pid->Kd_max);
}
void FuzzyPID_Init(FuzzyPID_t *pid, uint8_t mode, const fp32 PID[3], fp32 max_out, fp32 max_iout)
{
    if (pid == NULL || PID == NULL)
    {
        return;
    }

    pid->mode = mode;

    pid->Kp = PID[0];
    pid->Ki = PID[1];
    pid->Kd = PID[2];

    
    pid->Kp0 = pid->Kp;
    pid->Ki0 = pid->Ki;
    pid->Kd0 = pid->Kd;

    pid->max_out  = max_out;
    pid->max_iout = max_iout;

    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0.0f;
    pid->error[0] = pid->error[1] = pid->error[2] = 0.0f;
    pid->Pout = pid->Iout = pid->Dout = pid->out = 0.0f;

    
    pid->E_MAX   = 1.0f;
    pid->DE_MAX  = 0.5f;
    pid->DKP_MAX = 6.0f;
    pid->DKI_MAX = 0.02f;
    pid->DKD_MAX = 0.6f;

    
    pid->Kp_min = 0.0f;   pid->Kp_max = 20.0f;
    pid->Ki_min = 0.0f;   pid->Ki_max = 0.08f;
    pid->Kd_min = 0.0f;   pid->Kd_max = 2.0f;

    
    pid->fuzzy_enable = 1;

    pid->set = pid->fdb = 0.0f;
}

void FuzzyPID_SetFuzzyRange(FuzzyPID_t *pid, fp32 E_max, fp32 DE_max, fp32 DKp_max, fp32 DKi_max, fp32 DKd_max)
{
    if (pid == NULL) return;

    pid->E_MAX   = (E_max  > 1e-6f) ? E_max  : pid->E_MAX;
    pid->DE_MAX  = (DE_max > 1e-6f) ? DE_max : pid->DE_MAX;

    pid->DKP_MAX = (DKp_max >= 0.0f) ? DKp_max : pid->DKP_MAX;
    pid->DKI_MAX = (DKi_max >= 0.0f) ? DKi_max : pid->DKI_MAX;
    pid->DKD_MAX = (DKd_max >= 0.0f) ? DKd_max : pid->DKD_MAX;
}
void FuzzyPID_SetParaLimit(FuzzyPID_t *pid,
                           fp32 kp_min, fp32 kp_max,
                           fp32 ki_min, fp32 ki_max,
                           fp32 kd_min, fp32 kd_max)
{
    if (pid == NULL) return;

    pid->Kp_min = kp_min;  pid->Kp_max = kp_max;
    pid->Ki_min = ki_min;  pid->Ki_max = ki_max;
    pid->Kd_min = kd_min;  pid->Kd_max = kd_max;

    
    if (pid->Kp_min > pid->Kp_max) { fp32 t = pid->Kp_min; pid->Kp_min = pid->Kp_max; pid->Kp_max = t; }
    if (pid->Ki_min > pid->Ki_max) { fp32 t = pid->Ki_min; pid->Ki_min = pid->Ki_max; pid->Ki_max = t; }
    if (pid->Kd_min > pid->Kd_max) { fp32 t = pid->Kd_min; pid->Kd_min = pid->Kd_max; pid->Kd_max = t; }
}
void FuzzyPID_Enable(FuzzyPID_t *pid, uint8_t enable)
{
    if (pid == NULL) return;
    pid->fuzzy_enable = (enable != 0) ? 1 : 0;

    
    if (pid->fuzzy_enable == 0)
    {
        pid->Kp = pid->Kp0;
        pid->Ki = pid->Ki0;
        pid->Kd = pid->Kd0;
    }
}
void FuzzyPID_Clear(FuzzyPID_t *pid)
{
    if (pid == NULL)
    {
        return;
    }

    pid->error[0] = pid->error[1] = pid->error[2] = 0.0f;
    pid->Dbuf[0]  = pid->Dbuf[1]  = pid->Dbuf[2]  = 0.0f;
    pid->out = pid->Pout = pid->Iout = pid->Dout = 0.0f;
    pid->fdb = pid->set = 0.0f;

    
    pid->Kp = pid->Kp0;
    pid->Ki = pid->Ki0;
    pid->Kd = pid->Kd0;
}
fp32 FuzzyPID_Calc(FuzzyPID_t *pid, fp32 ref, fp32 set)
{
    if (pid == NULL)
    {
        return 0.0f;
    }

    
    pid->error[2] = pid->error[1];
    pid->error[1] = pid->error[0];

    pid->set = set;
    pid->fdb = ref;
    pid->error[0] = set - ref;

    fp32 e  = pid->error[0];
    fp32 de = pid->error[0] - pid->error[1];

    
    if (pid->fuzzy_enable)
    {
        fuzzy_update_gains(pid, e, de);
    }
    else
    {
        pid->Kp = pid->Kp0;
        pid->Ki = pid->Ki0;
        pid->Kd = pid->Kd0;
    }

    
    if (pid->mode == FUZZY_PID_POSITION)
    {
        pid->Pout = pid->Kp * pid->error[0];
        pid->Iout += pid->Ki * pid->error[0];

        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - pid->error[1]);
        pid->Dout = pid->Kd * pid->Dbuf[0];

        LimitMax(pid->Iout, pid->max_iout);
        pid->out = pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }
    else if (pid->mode == FUZZY_PID_DELTA)
    {
        pid->Pout = pid->Kp * (pid->error[0] - pid->error[1]);
        pid->Iout = pid->Ki * pid->error[0];

        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - 2.0f * pid->error[1] + pid->error[2]);
        pid->Dout = pid->Kd * pid->Dbuf[0];

        pid->out += pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }

    return pid->out;
}