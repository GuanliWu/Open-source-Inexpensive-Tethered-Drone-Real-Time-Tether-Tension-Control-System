#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "hx711.h"
#include "kalman.h"
#include <math.h>

int32_t value1;
int32_t value2;
float weight_raw1;
float weight_rea1;
float weight_raw2;
float weight_raw3;
float weight_rea2;
float weight_rea3;
int32_t reset1;
int32_t reset2;
float Weights = 100;
int32_t Weights_100=8768602;
static Kalman_t press_kf;
static Kalman_t press_kf2;
float R1 = 5.0f;
float R2 = 5.0f;
float p1;
float p2;

static uint8_t tare_done = 0;
static int32_t tare_adc1 = 0;
static int32_t tare_adc2 = 0;
static float tare_sum_raw = 0.0f;
float raw_sum = 0.0f;
float rea_sum = 0.0f;
uint8_t sum_tare_done = 0;
fp32 weight_raw_total = 0.0f;
fp32 weight_rea_total = 0.0f;
#define TARE_N 80

#define HX711_TS_MS      (12.5f)
#define DELAY_EPS        (1e-9f)

volatile float kalman_delay_ms_1 = 0.0f;
volatile float kalman_delay_ms_2 = 0.0f;
volatile float kalman_delay_ms_avg = 0.0f;

static uint8_t  delay_stat_inited = 0;
static uint16_t delay_upd_cnt = 0;

volatile float delay_err_inst = 0.0f;
volatile float delay_err_rms  = 0.0f;

#define ERR_RMS_N 80
static float err_sq_sum = 0.0f;
static uint16_t err_cnt = 0;


#define BUF_N        128             
#define LAG_MAX      20               
#define DELAY_UPD_N  10               

#define VAR_WIN      64              

#define VAR_TH       (1e-6f)
#define CORR_TH      (0.05f)
#define LAG_STEP_MAX (3)

static float raw_buf[BUF_N];
static float rea_buf[BUF_N];
uint16_t buf_idx = 0;
uint8_t  buf_full = 0;

uint16_t sample_cnt = 0;

volatile int   delay_lag_samples = 0;
float delay_meas_ms = 0.0f;

float delay_best_corr = 0.0f;
float xcorr_var = 0.0f;
uint8_t xcorr_updated = 0;

static inline float calc_delay_ms_from_K(float K)
{
    if (K < 1e-6f) K = 1e-6f;
    if (K > 0.999999f) K = 0.999999f;

    float d_samples = (1.0f - K) / (K + DELAY_EPS);
    return d_samples * HX711_TS_MS;
}

static inline int16_t wrap_idx(int16_t x)
{
    while (x < 0) x += BUF_N;
    while (x >= BUF_N) x -= BUF_N;
    return x;
}

static int estimate_delay_lag_xcorr(float *best_corr_out, uint16_t N_eff)
{
    if (N_eff < (LAG_MAX + 5)) {
        if (best_corr_out) *best_corr_out = 0.0f;
        return 0;
    }
    if (N_eff > BUF_N) N_eff = BUF_N;
    float mean_raw = 0.0f, mean_rea = 0.0f;
    for (uint16_t i = 0; i < N_eff; i++) {
        int idx = wrap_idx((int16_t)(buf_idx - 1 - (int16_t)i));
        mean_raw += raw_buf[idx];
        mean_rea += rea_buf[idx];
    }
    mean_raw /= (float)N_eff;
    mean_rea /= (float)N_eff;

    int best_lag = 0;
    float best_corr = -1e30f;

    for (int lag = 0; lag <= LAG_MAX; lag++)
    {
        float num = 0.0f, den1 = 0.0f, den2 = 0.0f;

        uint16_t M = (N_eff > (uint16_t)lag) ? (uint16_t)(N_eff - (uint16_t)lag) : 0;
        if (M < 10) break;

        for (uint16_t i = 0; i < M; i++)
        {
            int idx_raw = wrap_idx((int16_t)(buf_idx - 1 - (int16_t)i));
            int idx_rea = wrap_idx((int16_t)(buf_idx - 1 - (int16_t)i - (int16_t)lag));

            float x = raw_buf[idx_raw] - mean_raw;
            float y = rea_buf[idx_rea] - mean_rea;

            num  += x * y;
            den1 += x * x;
            den2 += y * y;
        }

        float corr = num / (den1 * den2 + 1e-12f);
        if (corr > best_corr) {
            best_corr = corr;
            best_lag = lag;
        }
    }

    if (best_corr_out) *best_corr_out = best_corr;
    return best_lag;
}

static float calc_recent_var_raw(uint16_t N_eff)
{
    uint16_t W = (N_eff < VAR_WIN) ? N_eff : VAR_WIN;
    if (W < 10) return 0.0f;

    float mean = 0.0f;
    for (uint16_t i = 0; i < W; i++) {
        int idx = wrap_idx((int16_t)(buf_idx - 1 - (int16_t)i));
        mean += raw_buf[idx];
    }
    mean /= (float)W;

    float var = 0.0f;
    for (uint16_t i = 0; i < W; i++) {
        int idx = wrap_idx((int16_t)(buf_idx - 1 - (int16_t)i));
        float d = raw_buf[idx] - mean;
        var += d * d;
    }
    var /= (float)W;
    return var;
}

static void HX711_TareOnce(void)
{
    int64_t s1 = 0, s2 = 0;
    for (int i = 0; i < TARE_N; i++)
    {
        s1 += HX711_GetData();
        s2 += HX711_GetData2();
        vTaskDelay(1);
    }
    tare_adc1 = (int32_t)(s1 / TARE_N);
    tare_adc2 = (int32_t)(s2 / TARE_N);

    reset1 = tare_adc1;
    reset2 = tare_adc2;

    Kalman_Init(&press_kf,  0.8f, 0.0f);
    Kalman_Init(&press_kf2, 0.8f, 0.0f);

    tare_done = 1;
}

void HX711_C_TASK(void const * argument)
{
    Kalman_Init(&press_kf, 0.8f, 0.0f);
    Kalman_Init(&press_kf2, 0.8f, 0.0f);
    HX711_TareOnce();

    while(1)
    {
			value1 = HX711_GetData();
			value2 = HX711_GetData2();

			weight_raw1=(float)(value1-reset1)*Weights/(float)(Weights_100-reset1);
			weight_raw2= (float)(value2-reset2)*Weights/(float)(Weights_100-reset2);
			weight_raw3 = -weight_raw2;

			Kalman_Predict(&press_kf);
			Kalman_Predict(&press_kf2);

			weight_rea1 = Kalman_Update(&press_kf,  weight_raw1, R1);
			weight_rea2 = Kalman_Update(&press_kf2, weight_raw2, R2);
			weight_rea3 = -weight_rea2;

			raw_sum = weight_raw1 + weight_raw3;
			rea_sum = weight_rea1 + weight_rea3;

			if (!sum_tare_done)
			{
				tare_sum_raw = raw_sum;
				sum_tare_done = 1;

				err_sq_sum = 0.0f;
				err_cnt = 0;

				buf_idx = 0;
				buf_full = 0;
				sample_cnt = 0;
				delay_stat_inited = 0;
				delay_upd_cnt = 0;

				delay_lag_samples = 0;
				delay_meas_ms = 0.0f;
				delay_best_corr = 0.0f;
				xcorr_var = 0.0f;
				xcorr_updated = 0;
			}

			raw_sum -= tare_sum_raw;
			rea_sum -= tare_sum_raw;

			weight_raw_total = raw_sum;
			weight_rea_total = rea_sum;
			delay_err_inst = raw_sum - rea_sum;
			err_sq_sum += delay_err_inst * delay_err_inst;
			err_cnt++;
			if (err_cnt >= ERR_RMS_N)
			{
					delay_err_rms = sqrtf(err_sq_sum / (float)ERR_RMS_N);
					err_sq_sum = 0.0f;
					err_cnt = 0;
			}

			kalman_delay_ms_1 = calc_delay_ms_from_K(press_kf.K_last);
			kalman_delay_ms_2 = calc_delay_ms_from_K(press_kf2.K_last);
			kalman_delay_ms_avg = 0.5f * (kalman_delay_ms_1 + kalman_delay_ms_2);

			raw_buf[buf_idx] = raw_sum;
			rea_buf[buf_idx] = rea_sum;

			buf_idx++;
			if (buf_idx >= BUF_N) {
					buf_idx = 0;
					buf_full = 1;
			}

			if (sample_cnt < BUF_N) sample_cnt++;

			if (!delay_stat_inited && sample_cnt >= (LAG_MAX + 20)) {
					delay_stat_inited = 1;
					delay_upd_cnt = 0;
			}

			if (delay_stat_inited)
			{
				delay_upd_cnt++;
				if (delay_upd_cnt >= DELAY_UPD_N)
				{
					delay_upd_cnt = 0;
					xcorr_updated = 0;

				 
					xcorr_var = calc_recent_var_raw(sample_cnt);
					if (xcorr_var > VAR_TH)
					{								
						float best_corr = 0.0f;
						int lag = estimate_delay_lag_xcorr(&best_corr, sample_cnt);
						delay_best_corr = best_corr;                   
						if (best_corr > CORR_TH)
						{
							int prev = delay_lag_samples;
							if (lag > prev + LAG_STEP_MAX) lag = prev + LAG_STEP_MAX;
							if (lag < prev - LAG_STEP_MAX) lag = prev - LAG_STEP_MAX;

							delay_lag_samples = lag;
							delay_meas_ms = (float)lag * HX711_TS_MS;
							xcorr_updated = 1;
						}
					}
				}
			}
			p2 = press_kf2.K_last;
			p1 = press_kf.K_last;

			vTaskDelay(13);
	}
}
