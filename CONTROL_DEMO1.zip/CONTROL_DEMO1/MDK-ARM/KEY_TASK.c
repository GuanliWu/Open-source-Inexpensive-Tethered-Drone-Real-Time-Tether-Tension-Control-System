#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "mcp2515.h"
uint16_t key_cnt = 0;
uint8_t key; 
uint8_t key_toggle = 0;
uint8_t  key_lock = 0;
uint8_t g_rx_pending = 0;
uint32_t last_send = 0;
uint8_t start = 0;
void USER_C_TASK(void const * argument)
{
	while(1)
	{
		key = HAL_GPIO_ReadPin(USER_GPIO_Port, USER_Pin);		
		if (key == 0) 
		{
			if (key_cnt < 10) 
				key_cnt++;
			else 
			{
				if (!key_lock) 
				{
					key_toggle ^= 1;  
					key_lock = 1;  
				}
			} 
		}
		else   
    {
        key_cnt = 0;
        key_lock = 0;              
    }		
		if (key_toggle == 0) 
		{
			vesc_set_current(0);
			start = 0;
		}
    else                 
		{
			start = 1;
		}
		vTaskDelay(1);
		
	}
}