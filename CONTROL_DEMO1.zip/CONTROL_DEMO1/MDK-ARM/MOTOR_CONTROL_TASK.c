#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "mcp2515.h"
#include <stdint.h>

mcp2515_frame_t g_rx_frame;
uint8_t g_rx_flag = 0;
extern uint32_t rx_ok_cnt;
extern  mcp2515_frame_t g_last_frame;

uint8_t g_can_irq = 0;


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == INT_Pin)
    {
        g_can_irq = 1;
    }
}

static inline int16_t sbe16(const uint8_t *p)
{
    return (int16_t)(((uint16_t)p[0] << 8) | p[1]);
}

static inline int32_t sbe32(const uint8_t *p)
{
    return (int32_t)(((uint32_t)p[0] << 24) |
                     ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8)  |
                      (uint32_t)p[3]);
}

vesc_raw_t g_vesc_raw;

void vesc_decode_raw(const volatile mcp2515_frame_t *f)
{
    if (!f || !f->ext || f->dlc != 8) return;

    uint8_t packet_id = (uint8_t)((f->sid >> 8) & 0xFF);

    switch (packet_id)
    {
        case 0x09: // STATUS_1
            g_vesc_raw.erpm = sbe32(&f->data[0]);
            g_vesc_raw.motor_current_x10 = sbe16(&f->data[4]);
            g_vesc_raw.duty_x1000 = sbe16(&f->data[6]);
            break;

        case 0x0A: // STATUS_2
            g_vesc_raw.ah_x10000 = sbe32(&f->data[0]);
            g_vesc_raw.ah_chg_x10000 = sbe32(&f->data[4]);
            break;

        case 0x0B: // STATUS_3
            g_vesc_raw.wh_x10000 = sbe32(&f->data[0]);
            g_vesc_raw.wh_chg_x10000 = sbe32(&f->data[4]);
            break;

        case 0x0C: // STATUS_4
            g_vesc_raw.temp_fet_x10   = sbe16(&f->data[0]);
            g_vesc_raw.temp_motor_x10 = sbe16(&f->data[2]);
            g_vesc_raw.current_in_x10 = sbe16(&f->data[4]);
            g_vesc_raw.pid_pos_x50    = sbe16(&f->data[6]);
            break;

        default:
            break;
    }
}

void MOTOR_C_TASK(void const * argument)
{
    uint32_t last_rx_cnt = 0;

    while (1)
    {
        
        if (g_can_irq)
        {
            g_can_irq = 0;
            mcp2515_service();
        }

        
        mcp2515_service();

        
        if (rx_ok_cnt != last_rx_cnt)
        {
            last_rx_cnt = rx_ok_cnt;

            g_rx_frame = g_last_frame;
            g_rx_flag = 1;
        }

        if (g_rx_flag)
        {
            g_rx_flag = 0;
            vesc_decode_raw(&g_rx_frame);
        }

        vTaskDelay(1);
    }
}
