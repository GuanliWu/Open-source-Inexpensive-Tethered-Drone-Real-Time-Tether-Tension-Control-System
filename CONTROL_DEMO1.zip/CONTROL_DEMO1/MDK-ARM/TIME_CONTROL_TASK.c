#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
uint16_t time;
void TIME_C_TASK(void const * argument)
{
	while(1)
	{
		time ++;
		if(time == 50)
		{
			HAL_GPIO_TogglePin(LED_G_GPIO_Port,LED_G_Pin);
			time = 0;						
		}
		vTaskDelay(1);
	}
}