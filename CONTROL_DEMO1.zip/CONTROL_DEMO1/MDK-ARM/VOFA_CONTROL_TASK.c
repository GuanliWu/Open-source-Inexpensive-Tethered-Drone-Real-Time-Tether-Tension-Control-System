#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "usart.h"
#include "mcp2515.h"
#define  channel 7
extern fp32 tenstion;
extern fp32 weight_rea_total;
extern float weight_raw1;
extern float weight_raw2;
extern float weight_rea1;
extern float weight_rea2;
extern fp32 pull_send;
float send_message[channel]; 
uint8_t count1,count2,count3;
extern vesc_raw_t g_vesc_raw;
float send[7];
 typedef struct 
{
	uint8_t message[(channel + 1) * 4];
	uint8_t temp[4];  
}Vofa_t;

Vofa_t Vofa;
typedef union 
{
	float float_data;
	unsigned long long_data;	
}FloatLongType;

void Float_to_Byte(float f,unsigned char byte[])  
{  
    FloatLongType Float;  
    Float.float_data=f;  
	
    byte[0]=(unsigned char)Float.long_data;  
    byte[1]=(unsigned char)(Float.long_data>>8);  
    byte[2]=(unsigned char)(Float.long_data>>16);  
    byte[3]=(unsigned char)(Float.long_data>>24);  
}  
void vofa_send_load(float*send_message)
{
	for(count1 = 0; count1 < channel; count1 ++)
	{
		Float_to_Byte(send_message[count1], Vofa.temp);
		for(count2 = 0; count2 < 4; count2++)
		{
			Vofa.message[count1*4+count2] = Vofa.temp[count2];
		}
	}
	Vofa.message[channel*4] = 0x00;
	Vofa.message[channel*4+1] = 0x00;
	Vofa.message[channel*4+2] = 0x80;
	Vofa.message[channel*4+3] = 0x7f;
}
fp32 speed = 0;
void VOFA_C_TASK(void const * argument)
{		
		while(1)
		{
				speed = (g_vesc_raw.erpm);
				send_message[0] = tenstion*10.0f;
				send_message[1] = weight_rea_total*10.0f;
				send_message[2] = pull_send;
				send_message[3] = speed;
				send_message[4] = 0;
				send_message[5] = 0;
				send_message[6] = 0;
				vofa_send_load(send_message);	
				HAL_UART_Transmit_DMA(&huart1, Vofa.message, sizeof(Vofa.message));			
				vTaskDelay(2);
			
		}
}